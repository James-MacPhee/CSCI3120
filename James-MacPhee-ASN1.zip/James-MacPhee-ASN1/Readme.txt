Compilation Instructions:
gcc -o sim sim.c
