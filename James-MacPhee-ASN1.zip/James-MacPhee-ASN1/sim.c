#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>

#define MAX_LINE 80 // The maximum length of command

int main(void){
	char *args[MAX_LINE/2 + 1]; //Command line arguments
	char input[MAX_LINE]; //User input before parsing
	const char delims[] = " \t\n"; //Appropriate delimiters for commands
	int should_run = 1; //Flag to determine when to exit program
	char *history[10]; //History of commands
	int i, num, cmd = 0; //History indexing
	pid_t pid_history[10]; //History of pids for commands	

	for(i=0; i<10; i++) history[i] = NULL;
	memset(pid_history, '\0', sizeof(pid_history));

	while(should_run){
		
		//Dealing with input
		printf("CSCI3120>"); //Prompt
		fflush(stdout); //Flushing standard output
		fgets(input, sizeof(input), stdin); //Grabbing whole command

		//Printing history
		if(strcmp(input, "history\n")==0){
			i = 0;
			printf("ID\t\tPID\t\tCommand\n");
			while(history[i]!=NULL && i<10){
				printf("%d\t\t%d\t\t%s", i+1, pid_history[i], history[i]);		
				i++;
			}
			continue;
		}

		//Checking for special commands
		if(input[0]=='!'){	
			if(input[1]==48){
				printf("Improper history index\n");
				continue;
			}
			else if(input[1]=='!'){
				if(history[0]==NULL){
					printf("No commands in history\n");
					continue;
				}
				else{
					printf("%s", history[0]);
					strcpy(input, history[0]);
				}
			}
			else if(input[1]==49){
				if(input[2]==48){
					if(history[9]!=NULL){
						printf("%s", history[9]);
						strcpy(input, history[9]);
					}
					else{
						printf("No such command in history\n");
						continue;
					}
				}
				else if(input[2]=='\n'){
					if(history[0]!=NULL){
						printf("%s", history[0]);
						strcpy(input, history[0]);
					}
					else{
						printf("No such command in history\n");
						continue;
					}
				}
				else{
					printf("Improper history index\n");
					continue;
				}
			}
			else if(history[input[1]-49]==NULL){
				printf("No such command in history\n");
				continue;
			}
			else{
				printf("%s", history[input[1]-49]);
				strcpy(input, history[input[1]-49]);
			}
		}
		
		//Getting history
		for(i=9; i>0; i--){
			history[i] = history[i-1];
		}
		history[0] = strdup(input);

		//Parsing inputted command
		i = 0;
		args[i] = strtok(input, delims);
		while(args[i] != NULL){
			i++;
			args[i] = strtok(NULL, delims);
		}

		//Handling exit call
		if(strcmp(args[0], "exit")==0){
			should_run = 0;
			exit(0);
		}
				
		//Dealing with the processes
		for(i=9; i>0; i--){
			pid_history[i] = pid_history[i-1];
		}
		pid_history[0] = fork(); //Create child process
		int status;
		if(pid_history[0] == 0){	
			if(execvp(args[0], args)<0){ //Invoked by child process
				printf("Error executing command\n");
			}
			exit(0); //Child process exits
		}
		else if(pid_history[0]==-1){
			printf("Error forking child.\n");
			exit(1);
		}
		else{
			//Parent process will wait for child process to exit
			while (wait(&status) != pid_history[0]);
		}
	}
	return 0;
}
