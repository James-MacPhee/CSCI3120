#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sys/errno.h>
#include "atcprint.h"
#include "airport.h"

#define ONE_DAY (24 * 60)

static void error(char *err) {
  fprintf(stderr, "%s : %s\n", err, strerror(errno));
  abort();
}
void *threadFunc(void *temp);
int n = 0;
flight_t **completed;
int waiting = 0;
pthread_barrier_t barrier;
pthread_mutex_t mutex1 = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t mutex2 = PTHREAD_MUTEX_INITIALIZER;

int main(int argc, char **argv) {

  int hour = 0;
  int minute = 0;
  int num = 0;
  char airline[20];
  char origin[20];
  char dest[20];
  flight_t *flight;

  while(1) {
    if (scanf("%s", airline) != 1) {
      error("Unexpected scanf failure");
    } else if (!strcmp(airline, "end")) {
      break;
    } 
 
    flight = malloc(sizeof(flight_t));
    assert(flight);
    memset(flight, 0, sizeof(flight_t));

    if ((scanf("%d", &flight->f_no) != 1) || (scanf("%d", &flight->pid) != 1) ||
        (scanf("%s", origin) != 1) || (scanf("%d:%d", &hour, &minute) != 2) || 
        (scanf("%d", &flight->length) != 1) || (scanf("%s", dest) != 1)) {
      error("Unexpected scanf failure");
    }
  
    strcpy(flight->airline, airline);
    flight->origin = airport_get(origin);
    flight->departure = 60 * hour + minute;
    flight->destination = airport_get(dest);
    airport_schedule(flight);
    num++;
  }

  completed = malloc(sizeof(flight_t *) * num);
  assert(completed);

  airport_t *apt;
  pthread_t threads[airport_num()];
  pthread_barrier_init(&barrier, NULL, airport_num());
  
  int i = 0;
  for(apt = airport_next(NULL); apt != NULL; apt = airport_next(apt)){
    pthread_create(&threads[i], NULL, threadFunc, (void *)apt);
    i++;
  }
  int j;
  for(j = 0; j < airport_num(); j++){
    pthread_join(threads[j], NULL);
  }
  
  atcprint(completed, n);
  return 0;
}

//Function for each threads simulation of each day
void *threadFunc(void *temp){
  
  flight_t *flight;
  airport_t *apt;
  apt = (airport_t *)temp;

  for (int i = 0; i < ONE_DAY; i++) {
    flight = airport_step(apt, i);
    if (flight) {
      pthread_mutex_lock(&mutex1);
      completed[n] = flight;
      pthread_mutex_unlock(&mutex1);
      pthread_mutex_lock(&mutex2);
      n++;
      pthread_mutex_unlock(&mutex2);
    }
    pthread_barrier_wait(&barrier);
  }
}
