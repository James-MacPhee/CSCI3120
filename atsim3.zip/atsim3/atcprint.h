#ifndef ATCPRINT_H
#define ATCPRINT_H

#include "airport.h"

extern void atcprint(flight_t **f, int size);

#endif
