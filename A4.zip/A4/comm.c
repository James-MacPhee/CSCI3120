#include <stdlib.h>
#include "pqueue.h"
#include "comm.h"

typedef struct mailbox_ mailbox;
struct mailbox_{
  pqueue_t *box;
  int id;
  
};
static mailbox *mailboxes[2000];
static int count = 0;

extern int comm_allocate(){
  mailbox *m = malloc(sizeof(mailbox));
  m->box = pqueue_new();
  m->id = count;
  mailboxes[count] = m;
  count++; 
  return count-1;
}
extern int comm_send(int id, void *buf){
  mailbox *m = mailboxes[id];
  pqueue_t *q = m->box;
  pqueue_enqueue(q, 0, buf);
  return 1;
}
extern void *comm_recv_any(int id){
  mailbox *m = mailboxes[id];
  pqueue_t *q = m->box;
  void *buf = pqueue_dequeue(q);
  return buf;
}
extern int comm_size(int id){
  mailbox *m = mailboxes[id];
  return pqueue_size(m->box);
}
