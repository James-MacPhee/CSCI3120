#ifndef COMM_H
#define COMM_H

extern int comm_allocate();
extern int comm_send(int id, void *buf);
extern void *comm_recv_any(int id);
extern int comm_size(int id);

#endif
