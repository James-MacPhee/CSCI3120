Compilation Instructions:
gcc -pthread -o sim sim.c

Execution Instructions (replace quotations with actual file name - ex: IntegerList.txt):
./sim "name of IntegerList file" > SortedIntegerList.txt
