/* Author: James MacPhee
 * Class: CSCI3120
 * Program: Demonstrates multithreading in C with array sorting
 */
#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>

//Function prototypes
void *sorter(void *params); //Thread that performs basic sorting algortithm
void *merger(void *params); //Thread that performs merging of results

//Global variables/objects
int unsort[501], sort[501];
FILE *file;
pthread_t sort1, sort2, merge;

//Structs typedef
typedef struct{
	int starting_index;
	int ending_index;
} parameters;

//Main function
int main(int argc, char *argv[]){
	
	//Reading and parsing input
	file = fopen(argv[1], "r"); //Opening file
	int temp, i = 0;
	if(file){
		while(fscanf(file, "%d%*c", &unsort[i]) != EOF){ //Safelt grabbing integers
			i++;
		}
	}
	if(file){
		fclose(file);
	}
	int length = i;
	//Create first sorting thread
	parameters *data1 = (parameters *)malloc(sizeof(parameters));
	data1->starting_index = 0;
	data1->ending_index = length/2 - 1;
	pthread_create(&sort1, NULL, sorter, (void *)data1);
	//Create second sorting thread
	parameters *data2 = (parameters *)malloc(sizeof(parameters));
	data2->starting_index = length/2;
	data2->ending_index = length - 1;
	pthread_create(&sort2, NULL, sorter, (void *)data2);
	//wait for sorting threads to finish
	pthread_join(sort1, NULL);
	pthread_join(sort2, NULL);
	//create merge thread
	parameters *data3 = (parameters *)malloc(sizeof(parameters));
	data3->starting_index = length/2 - 1;
	data3->ending_index = length-1;
	pthread_create(&merge, NULL, merger, (void *)data3);
	//wait for merge thread to finish
	pthread_join(merge, NULL);
	//output sorted array
	for(i=0;i<length;i++){
		printf("%d ", sort[i]);
	}
	printf("\n");
	return 0;
}

//I will be using Bubblesort, no reference except my notes from previous class (CSCI2132)
void *sorter(void *params){
	parameters *new_params = (parameters *)params;
	int start = new_params->starting_index;
	int end = new_params->ending_index+1;
	int j, k, tmp;
	for(j=start;j<end;j++){
		for(k=start+1;k<end;k++){
			if(unsort[k-1]>unsort[k]){
				tmp = unsort[k-1];
				unsort[k-1] = unsort[k];
				unsort[k] = tmp;
			}
		}
	}
}

//Basic merging of two sorted arrays
void *merger(void *params){
	parameters *new_params = (parameters *)params; 
	int j = 0, count = 0;
	int mid = new_params->starting_index+1;
	int k = mid;
	int end = new_params->ending_index+1;
	while(j<mid && k<end){
		if(unsort[j]<unsort[k]){
			sort[count] = unsort[j];
			count++;
			j++;
		}
		else{
			sort[count] = unsort[k];
			count++;
			k++;
		}
	}
	//Storing any leftover number in certain cases
	while(j<mid){
		sort[count] = unsort[j];
		count++;
		j++;
	}
	while(k<end){
		sort[count] = unsort[k];
		count++;
		k++;
	}
}
