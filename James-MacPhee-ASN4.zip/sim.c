/* Author: James MacPhee - Course: CSCI3120
 * Program: Converts inputted logical addresses to physical addresses
 */

#include <stdio.h>
#include <string.h>

//Method prototypes
int readInput(char *fileName1, char *fileName2);

//Global Variables
int frameNum[5];
int logicalAddresses[11];
FILE *infile;

//Main Function
int main(int argc, char *argv[]){
	int num = readInput(argv[1], argv[2]);
	int i;
	//Loop through all logical addresses
	for(i=0;i<num;i++){
		int pageNumber = logicalAddresses[i]/4; //Grab page #
		int movement = logicalAddresses[i]%4; //Amount to move on page
		int frameNumber = frameNum[pageNumber]; //Page # -> frame #
		int physicalAddress = frameNumber*4+movement;
		printf("%d\n", physicalAddress);
	}
	return 0;
}

//Function to take input
int readInput(char *fileName1, char *fileName2){
	//Grabbing logicalAddresses info
	infile = fopen(fileName1, "r");
	int i = 0;
	while(fscanf(infile, "%d", &logicalAddresses[i]) != EOF){
		i++;
	}
	fclose(infile);
	
	//Grabbing pageTable info
	infile = fopen(fileName2, "r");
	int pageNum;
	int tempFrame;
	while(fscanf(infile, "%d,%d", &pageNum, &tempFrame) != EOF){
		frameNum[pageNum] = tempFrame;
	}
	fclose(infile);
	return i;
}
