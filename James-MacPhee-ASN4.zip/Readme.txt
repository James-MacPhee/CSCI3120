Compilation Instructions:
gcc -o sim sim.c

Execution Instructions:
./sim LogicalAddress.txt PageTable.txt > PhysicalAddresses.txt
