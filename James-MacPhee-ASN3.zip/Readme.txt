Compilation Instructions:
gcc -o sim sim.c pqueue.c

Execution Instructions:
./sim Taskspec.txt
