/* Author: James MacPhee
 * Course: CSCI3120
 * Program: Simulates CPU Scheduling
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "pqueue.h"

//Function Prototypes
int readInput();
void FCFS();
void RR();
void NSJF();
void PSJF();

//Structs typedef
typedef struct{
	char taskNum;
	char arrival;
	char burst;
} process;

//Global variables/objects
FILE *infile;
pqueue_t *queue1;
pqueue_t *queue2;
pqueue_t *temp_SJF_queue;
process *queue3[51];
pqueue_t *temp_PSJF_queue;
process *queue4[51];
int numProcesses;

//Main function
int main(int argc, char *argv[]){
	queue1 = pqueue_new();
	queue2 = pqueue_new();
	temp_SJF_queue = pqueue_new();
	temp_PSJF_queue = pqueue_new();
	readInput(argv[1]); //Read in processes to be scheduled
	
	//First Come First Serve
	printf("FCFS:\n");
	FCFS();
	printf("\n\n*******************\n\n");

	//Round Robin
	printf("RR:\n");
	RR();
	printf("\n\n*******************\n\n");
	
	//Non-preemptive Shortest Job First
	printf("NSJF:\n");
	NSJF();
	printf("\n\n*******************\n\n");
	
	//Preemptive Shortest Job First
	printf("PSJF:\n");
	PSJF();
	printf("\n");
	return 0;
}

//Function to read input from file and prepare array of process structs
int readInput(char *filename){
	infile = fopen(filename, "r");
	char line[10];
	char *parsed[4];
	
	while(fgets(line,  sizeof(line), infile) != NULL){
		process *tmp = (process *)malloc(sizeof(process));
		//RR & PSJFgets it's own processes because it alters the burst
		process *tmp2 = (process *)malloc(sizeof(process));
		process *tmp3 = (process *)malloc(sizeof(process));

		//Parsing each line into process components
		parsed[0] = strtok(line, "T,\n");
		parsed[1] = strtok(NULL, "T,\n");
		parsed[2] = strtok(NULL, "T,\n");
		
		//Creating appropriate process struct
		tmp->taskNum = atoi(parsed[0]);
		tmp2->taskNum = atoi(parsed[0]);
		tmp3->taskNum = atoi(parsed[0]);
		tmp->arrival = atoi(parsed[1]);
		tmp2->arrival = atoi(parsed[1]);
		tmp3->arrival = atoi(parsed[1]);
		tmp->burst = atoi(parsed[2]);
		tmp2->burst = atoi(parsed[2]);
		tmp3->burst = atoi(parsed[2]);
		
		//Adding temp process struct to queues of processes
		pqueue_enqueue(queue1, tmp->arrival, tmp);
		pqueue_enqueue(queue2, tmp2->arrival, tmp2);
		pqueue_enqueue(temp_SJF_queue, tmp->burst, tmp);
		pqueue_enqueue(temp_PSJF_queue, tmp3->burst, tmp3);
	}
	/* For NSJF and PSJF i decided to use arrays instead of queues
	 * Since I already implemented a priorty queue, instead of just putting
	 * the processes in an array and then implementing a sorting algorithm
	 * I simply added them to the queue (which sorted them) then moved them
	 * to the array below */
	int i = 0;
	while(pqueue_size(temp_SJF_queue) > 0){
		queue3[i] = pqueue_dequeue(temp_SJF_queue);
		queue4[i] = pqueue_dequeue(temp_PSJF_queue);
		i++;
	}
	numProcesses = pqueue_size(queue1);
	fclose(infile);
}

//First Come First Serve implementation
void FCFS(){
	int time = 0;
	int waitTime = 0;

	while(pqueue_size(queue1) > 0){
		process *temp = pqueue_dequeue(queue1);
		
		//Setting+ temporary variable to cut down on '->' notation below
		int arr = temp->arrival;
		int bur = temp->burst;	
		int num = temp->taskNum;
		
		if(arr>=time) time = arr; //Can't run a process until it arrives
		else waitTime += (time-arr);
		printf("T%d  %d  %d\n", num, time, time + bur);
		time += bur; //Updating time
	}
	printf("Average Waiting Time: %.2f", (double)waitTime/numProcesses);
}

//Round Robin implementation
void RR(){
	int quantum = 4;
	int time = 0;
	int waitTime = 0;

	while(pqueue_size(queue2) > 0){
		process *temp = pqueue_dequeue(queue2);
		
		//Same as in FCFS
		int arr = temp->arrival;
		int bur = temp->burst;
		int num = temp->taskNum;
		
		if(arr>=time) time = arr;
		//If job length is less than quantum then complete it and remove it from queue
		if(bur<=quantum){
			printf("T%d  %d  %d\n", num, time, time + bur);
			waitTime += (time-arr);
			time += bur;
		}
		//Otherwise complete quantum's time worth of the job and put back in queue
		else{
			printf("T%d  %d  %d\n", num, time, time + quantum);
			temp->burst = bur-quantum;
			waitTime -= quantum;
			time += quantum;
			pqueue_enqueue(queue2, time, temp);
		}
	}
	printf("Average Waiting Time: %.2f", (double)waitTime/numProcesses);
}

//Non-preemptive Shortest Job First implementation
void NSJF(){
	int waitTime = 0;
	int time = 0;
	int processesLeft = numProcesses;

	while(processesLeft > 0){
		int i, j;
		//Finding shortest job that has arrived
		for(i=0;i<processesLeft;i++){
			if(queue3[i]->arrival <= time){
				//Same as two above
				int arr = queue3[i]->arrival;
				int bur = queue3[i]->burst;
				int num = queue3[i]->taskNum;
				
				//Printout
				printf("T%d  %d  %d\n", num, time, time+bur);
				waitTime += (time-arr);
				time += bur;
				break;
			}
		}
		//Moving remaining jobs up
		for(j=i+1;j<processesLeft;j++) queue3[j-1] = queue3[j];
		queue3[j-1] = NULL;
		processesLeft--;
	}
	printf("Average Waiting Time: %.2f", (double)waitTime/numProcesses);
}

//Preemptive Shortest Job First implementation
void PSJF(){
	int waitTime = 0;
	int time = 0;
	int startTime;
	int new = 0;
	int processesLeft = numProcesses;
	process *current;

	while(processesLeft > 0){
		int i, j;

		//Finding shortest job that has arrived
		for(i=0;i<processesLeft;i++){
			if(queue4[i]->arrival <= time){
				current = (process *)malloc(sizeof(process));
				if(new==0) startTime = time;
				break;
			}
		}
		time++;

		//These next lines determine if a processes is to be preempted
		for(j=0;j<i;j++){
			if(queue4[j]->arrival <= time) break;
		}
		
		//Then if there is a shorter job arrived, printout current info
		if(j<i-1){
			//Printout
			int arr = queue4[i]->arrival;
			int bur = queue4[i]->burst;
			int num = queue4[i]->taskNum;
			printf("T%d  %d  %d\n", num, startTime, time);
			queue4[i]->burst = bur-(time-startTime);
			waitTime -= (time-startTime);
			new = 0;
			continue; 
		}

		//This part runs if the current process is still the shortest
		if((time-startTime) == queue4[i]->burst){
			//Printout
			int arr = queue4[i]->arrival;
			int bur = queue4[i]->burst;
			int num = queue4[i]->taskNum;
			printf("T%d  %d  %d\n", num, startTime, time);
			
			waitTime += startTime-arr;
			
			//Moving remaining processes up
			for(j=i+1;j<processesLeft;j++) queue4[j-1] = queue4[j];
			queue4[j-1] = NULL;
			processesLeft--;
			new = 0;
		}
		else new = 1;
	}
	printf("Average Waiting Time: %.2f", (double)(waitTime)/numProcesses);
}
